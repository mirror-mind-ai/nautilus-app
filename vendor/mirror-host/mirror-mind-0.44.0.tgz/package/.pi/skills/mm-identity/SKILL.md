---
name: "mm-identity"
description: Read and update identity directly in the database
user-invocable: true
---

# Identity

After the initial seed, the database is the source of truth for identity.
Use these commands to inspect and edit identity directly — no YAML files needed.

## Usage

```
/mm-identity list [--layer LAYER]
/mm-identity get <layer> <key>
/mm-identity set <layer> <key> --content "..."
/mm-identity edit <layer> <key>
```

---

## Subcommands

### list

List all identity entries currently stored in the database. Answered by the TS core (CV22.DS7.US1).

```bash
mirror identity list [--layer LAYER] [--mirror-home PATH]
```

**Examples:**
- `mirror identity list` — all entries
- `mirror identity list --layer ego` — only ego layer

Layers: `self`, `ego`, `user`, `organization`, `persona`, `journey`, `journey_path`

---

### get

Print the full content of one identity entry. Answered by the TS core (CV22.DS7.US1).

```bash
mirror identity get <layer> <key> [--mirror-home PATH]
```

**Examples:**
- `mirror identity get ego behavior`
- `mirror identity get self soul`
- `mirror identity get persona engineer`

---

### set

Update identity content directly in the database.

```bash
mirror identity set <layer> <key> --content "..." [--mirror-home PATH]
mirror identity set <layer> <key> --file <path>  [--mirror-home PATH]
```

If neither `--content` nor `--file` is given, content is read from stdin.

For anything longer than a line, write the text to a file and pass `--file`:
Mirror reads it as bytes, so the shell never splits, substitutes, or re-encodes
it. On Windows PowerShell 5.1 it is the only safe route: the pipe is ASCII by
default and turns every accented letter into `?`. The pipe stays for one-liners.

A new `journey` or `persona` key must be kebab-case: lowercase letters, digits,
and single hyphens, up to 80 characters, such as `product-launch`. Agents put
these keys into commands, so `set` and `edit` refuse any other new key and name
one that would work. A key created before this rule keeps working.

**Examples:**
- `mirror identity set ego behavior --content "Be direct."`
- `mirror identity set self soul --file new-soul.md`
- `echo "Be direct." | mirror identity set ego behavior` (a one-liner; not on PowerShell 5.1)

---

### edit

Open the current content in `$EDITOR`, edit it, and save back to the database on close.

```bash
mirror identity edit <layer> <key> [--mirror-home PATH]
```

**Examples:**
- `mirror identity edit ego behavior`
- `mirror identity edit self soul`
- `mirror identity edit persona engineer`

If no changes are detected, nothing is written. If the file is left empty, the edit is aborted.

---

## When receiving `/mm-identity [subcommand] [args]`

Run the corresponding command above and present the output to the user.
